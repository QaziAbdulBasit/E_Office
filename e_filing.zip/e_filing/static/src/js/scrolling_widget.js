odoo.define('e_filing.scrolling_widget', function (require) {
    'use strict';

    var FormController = require('web.FormController');
    var core = require('web.core');

    var qweb = core.qweb;

    FormController.include({
        _onSave: function () {
            this._super.apply(this, arguments);
            this._enableFieldScrolling();
        },

        _enableFieldScrolling: function () {
            var self = this;
            setTimeout(function () {
                var $scrollableFields = self.$('.scrollable-field');
                $scrollableFields.each(function () {
                    var $field = $(this);
                    var fieldHeight = $field.outerHeight();
                    var contentHeight = $field.get(0).scrollHeight;
                    if (contentHeight > fieldHeight) {
                        $field.css('overflow-y', 'scroll');
                    }
                });
            }, 100);
        },
    });
});
